
//------------------------------------------------------------------------------
/*! \brief FireSpreadAtVectorFromBeta
 *
 *  Dependent Variables (Outputs)
 *      vSurfaceFireSpreadAtVector (ft/min)
 *
 *  Independent Variables (Inputs)
 *      vSurfaceFireEccentricity (fraction)
 *      vSurfaceFireSpreadAtHead (ft/min)
 *      vSurfaceFireVectorBeta (degrees)
 */
void EqCalc::FireSpreadAtVectorFromBeta( void )
{
    // Access current input values
    double eccent = vSurfaceFireEccentricity->m_nativeValue;
    double rosMax = vSurfaceFireSpreadAtHead->m_nativeValue;
    double beta   = vSurfaceFireVectorBeta->m_nativeValue;
    // Calculate results
    double rosVec  = FBL_SurfaceFireSpreadRateAtBeta( rosMax, eccent, beta );
    // Store results
    vSurfaceFireSpreadAtVector->update( rosVec );
    return;
}

//------------------------------------------------------------------------------
/*! \brief FireSpreadAtPsi
 *
 *  Dependent Variables (Outputs)
 *      vSurfaceFireSpreadAtPsi (ft/min)
 *
 *  Independent Variables (Inputs)
 *		vSurfaceFireEllipseF (ft)
 *		vSurfaceFireEllipseG (ft)
 *		vSurfaceFireEllipseH (ft)
 *      vSurfaceFireElapsedTime (min)
 *      vSurfaceFireVectorPsi (degrees)
 *
 *  NOTE: Changed as of Build 617 to use rates rather than distances,
 *  thus eliminating the need of elapsed time as an input
 *
 *  Independent Variables (Inputs)
 *		vSurfaceFireSpreadAtBack (ft/min)
 *		vSurfaceFireSpreadAtHead( ft/min)
 *		vSurfaceFireLengthToWidth (ratio)
 *      vSurfaceFireVectorPsi (degrees)
 */
void EqCalc::FireSpreadAtPsi( void )
{
    // Access current input values
    double psi = vSurfaceFireVectorPsi->m_nativeValue;
	// Before Build 617
	double f = vSurfaceFireEllipseF->m_nativeValue;
	double g = vSurfaceFireEllipseG->m_nativeValue;
	double h = vSurfaceFireEllipseH->m_nativeValue;
	double t = vSurfaceFireElapsedTime->m_nativeValue;
	// As of Build 617
	double rosBack = vSurfaceFireSpreadAtHead->m_nativeValue;
	double rosHead = vSurfaceFireSpreadAtBack->m_nativeValue;
	double lwRatio = vSurfaceFireLengthToWidth->m_nativeValue;
	double length  = rosHead + rosBack;
	double width   = length / lwRatio;
	f = FBL_SurfaceFireEllipseF( length );
	g = FBL_SurfaceFireEllipseG( length, rosBack );
	h = FBL_SurfaceFireEllipseH( width );
	t = 1.0;

	// Calculate results
    double rosVec = FBL_SurfaceFireExpansionRateAtPsi( f, g, h, t, psi );
    // Store results
    vSurfaceFireSpreadAtPsi->update( rosVec );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'beta' in degrees given 'theta' in degrees.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param thetaDegrees 'Theta', the angle in degrees between the direction of maximum spread
 *           (the ellipse's major axis) and a line segment between the fire ellipse
 *            center and the point 'p' determined by \a betaDegrees.
 *
 *  \return 'Beta', the angle (degrees) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ignition \a point.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 */
double FBL_SurfaceFireEllipseBetaFromThetaDegrees( double f, double g, double h,
        double thetaDegrees )
{
    double thetaRadians = FBL_CompassDegreesToRadians(
                            FBL_CompassConstrainDegrees( thetaDegrees ) );
    double betaRadians = FBL_SurfaceFireEllipseBetaFromThetaRadians( f, g, h,
                            thetaRadians );
    double betaDegrees = FBL_CompassRadiansToDegrees( betaRadians );
    return( betaDegrees );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'beta' in radians given 'theta' in radians.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param thetaRadians Theta, the angle in radians between the direction of maximum spread
 *           (the ellipse's major axis) and a line segment between the fire ellipse
 *           center and the point 'p' determined by \a betaRadians.
 *
 *  \param 'Beta', the angle (radians) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ignition \a point.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 *
 */
double FBL_SurfaceFireEllipseBetaFromThetaRadians( double f, double g, double h,
        double thetaRadians )
{
	double num = h * sin( thetaRadians );
	double denom = g + f * cos( thetaRadians );
	double betaRadians = ( denom != 0. ) ? atan( num / denom ) : 0.;

	if ( betaRadians < 0. )
	{
		betaRadians += M_PI;
	}
	if ( thetaRadians > M_PI )
	{
		betaRadians += M_PI;
	}
    return( betaRadians );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'psi' in degrees.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param theta Angle in degrees between the direction of maximum fire spread
 *           (the ellipse's major axis) and an arbitrary vector emanating
 *           from the ellipse \a center.  The arbitrary vector intersects
 *           the fire ellipse perimeter at some point 'p'.
 *
 *  \return Psi, the angle in degrees between direction of maximum fire spread
 *  (the ellipse's major axis) and the normal of the tangent to the ellipse
 *  at point 'p' as determined by \a thetaDegrees.
 */

double FBL_SurfaceFireEllipsePsiFromThetaDegrees( double f, double h, double thetaDegrees )
{
    double thetaRadians = FBL_CompassDegreesToRadians(
                            FBL_CompassConstrainDegrees( thetaDegrees ) );
    double psiRadians   = FBL_SurfaceFireEllipsePsiFromThetaRadians( f, h, thetaRadians );
    double psiDegrees   = FBL_CompassRadiansToDegrees( psiRadians );
    return( psiDegrees );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'psi' in radians.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param theta Angle in radians between the direction of maximum fire spread
 *           (the ellipse's major axis) and an arbitrary vector emanating
 *           from the ellipse \a center.  The arbitrary vector intersects
 *           the fire ellipse perimeter at some point 'p'.
 *
 *  \return Psi, the angle in radians between direction of maximum fire spread
 *  (the ellipse's major axis) and the normal of the tangent to the ellipse
 *  at point 'p' as determined by \a thetaRadians.
 */

double FBL_SurfaceFireEllipsePsiFromThetaRadians( double f, double h, double thetaRadians )
{
	if ( f == 0. || h == 0. )
	{
		return( 0. );
	}
    double tanPsi     = tan( thetaRadians ) * f / h;
    double psiRadians = atan( tanPsi );

	// Adjust for quadrant
	double boundary1 = 0.5 * M_PI;
	double boundary2 = 1.5 * M_PI;
	if ( thetaRadians < boundary1 )
	{
		// No adjustment needed
	}
	else if ( thetaRadians >= boundary1 && thetaRadians <= boundary2 )
	{
		psiRadians += M_PI;
	}
	else if ( thetaRadians > boundary2 )
	{
		psiRadians += (2. * M_PI);
	}
    return( psiRadians );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'theta' in degrees given beta in degrees.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param betaDegrees Angle (degrees) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ignition \a point.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 *
 *  \return Theta, the angle in degrees between the direction of maximum spread
 *  (the ellipse's major axis) and a line segment between the fire ellipse
 *  center and the point 'p' determined by \a betaDegrees.
 */
double FBL_SurfaceFireEllipseThetaFromBetaDegrees( double f, double g, double h,
        double betaDegrees )
{
    double betaRadians  = FBL_CompassDegreesToRadians(
                            FBL_CompassConstrainDegrees( betaDegrees ) );
    double thetaRadians = FBL_SurfaceFireEllipseThetaFromBetaRadians( f, g, h,
                            betaRadians );
    double thetaDegrees = FBL_CompassRadiansToDegrees( thetaRadians );
	if ( betaDegrees > 180. )
	{
		thetaDegrees = 360. - thetaDegrees;
	}
    return( thetaDegrees );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'theta' in radians given 'beta' in radians.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param betaRadians Angle (radians) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ignition \a point.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 *
 *  \return Theta, the angle in radians between the direction of maximum spread
 *  (the ellipse's major axis) and a line segment between the fire ellipse
 *  center and the point 'p' determined by \a betaRadians.
 */
double FBL_SurfaceFireEllipseThetaFromBetaRadians( double f, double g, double h,
        double betaRadians )
{
    double cosBeta  = cos( betaRadians );
    double cos2Beta = cosBeta * cosBeta;
    double sin2Beta = 1.0 - cos2Beta;
    double f2 = f * f;
    double g2 = g * g;
    double h2 = h * h;
    double term = sqrt( h2 * cos2Beta + ( f2 - g2 ) * sin2Beta );
    double num  = h * cosBeta * term - ( f * g * sin2Beta );
    double denom = h2 * cos2Beta + f2 * sin2Beta;
    double cosTheta = num / denom;
    double thetaRadians = acos( cosTheta );
    return( thetaRadians );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'theta' in degrees given 'psi' in degrees.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param psiDegrees Psi, the angle in degrees between direction of maximum fire
 *			  spread (the ellipse's major axis) and the normal of the tangent to
 *			  the ellipse at point 'p' as determined by \a thetaRadians.
 *
 *  \return Theta, the angle in degrees between the direction of maximum spread
 *  (the ellipse's major axis) and a line segment between the fire ellipse
 *  center and the point 'p' determined by \a betaDegrees.
 */
double FBL_SurfaceFireEllipseThetaFromPsiDegrees( double f, double h, double psiDegrees )
{
    double psiRadians   = FBL_CompassDegreesToRadians(
                            FBL_CompassConstrainDegrees( psiDegrees ) );
    double thetaRadians = FBL_SurfaceFireEllipseThetaFromPsiRadians( f, h, psiRadians );
    double thetaDegrees = FBL_CompassRadiansToDegrees( thetaRadians );
    return( thetaDegrees );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse angle 'theta' in radians givem 'psi' in radians.
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param psiRadians Psi, the angle in radians between direction of maximum fire
 *			  spread (the ellipse's major axis) and the normal of the tangent to
 *			  the ellipse at point 'p' as determined by \a thetaRadians.
 *
 *  \return Theta, the angle in radians between the direction of maximum spread
 *  (the ellipse's major axis) and a line segment between the fire ellipse
 *  center and the point 'p' determined by \a betaRadians.
 */
double FBL_SurfaceFireEllipseThetaFromPsiRadians( double f, double h, double psiRadians )
{
	double tanThetaRadians = tan( psiRadians ) * h / f;
	double thetaRadians = atan( tanThetaRadians );

	// Adjust for the quadrant
	double boundary1 = 0.5 * M_PI;
	double boundary2 = 1.5 * M_PI;
	if ( psiRadians < boundary1 )
	{
		// no adjustment required
	}
	else if ( psiRadians >= boundary1 && psiRadians < boundary2 )
	{
		thetaRadians += M_PI;
	}
	else if ( psiRadians >= boundary2 )
	{
		thetaRadians += ( 2. * M_PI );
	}
    return( thetaRadians );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse expansion rate at point 'p', the
 *  intersection of the fire ellipse perimeter with a fire spread vector
 *  emanating from the ignition point and at 'beta' degrees from the direction
 *  of maximum fire spread (the ellipse's major axis).
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param elapsedTime Elapsed time from fire ignition (assuming steady spread rate).
 *  \param betaDegrees Angle (degrees) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ignition \a point.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 *
 *  \return The rate of expansion of the fire ellipse at point 'p' in the
 *  direction normal to the tangent of the ellipse perimeter at point 'p'.
 */
double FBL_SurfaceFireExpansionRateAtBeta( double f, double g, double h,
            double elapsedTime, double betaDegrees )
{
    double thetaDeg = FBL_SurfaceFireEllipseThetaFromBetaDegrees( f, g, h, betaDegrees );
    double rate     = FBL_SurfaceFireExpansionRateAtTheta( f, g, h, thetaDeg,
        elapsedTime );
    return( rate );
}
//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse expansion rate at point 'p', the
 *  intersection of the fire ellipse perimeter with a line forming an angle
 *  'psi' with the direction of maximum fire spread (the ellipse's major axis).
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param elapsedTime Elapsed time from fire ignition (assuming steady spread rate).
 *  \param psiDegrees The angle in degrees between the direction of maximum
 *           fire spread (the ellipse's major axis) and the normal of the
 *           tangent to the ellipse at point 'p'.
 *
 *  \return The rate of expansion of the fire ellipse at point 'p' in the
 *  direction normal to the tangent of the ellipse perimeter at point 'p'.
 */
double FBL_SurfaceFireExpansionRateAtPsi( double f, double g, double h,
            double elapsedTime, double psiDegrees )
{
    if ( elapsedTime < SMIDGEN )
    {
        return( 0.0 );
    }
    double psiRadians = FBL_CompassDegreesToRadians(
                            FBL_CompassConstrainDegrees( psiDegrees ) );
    double cosPsi     = cos( psiRadians );
    double cos2Psi    = cosPsi * cosPsi;
    double sin2Psi    = 1.0 - cos2Psi;
    double fr         = f / elapsedTime;
    double gr         = g / elapsedTime;
    double hr         = h / elapsedTime;
    double term1      = gr * cosPsi;
    double term2      = fr * fr * cos2Psi;
    double term3      = hr * hr * sin2Psi;
    double rate       = term1 + sqrt( term2 + term3 );
    return( rate );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire ellipse expansion rate at point 'p', the
 *  intersection of the fire ellipse perimeter with a line emanating from the
 *  ellipse center and at 'theta' degrees from the direction of maximum fire
 *  spread (the ellipse's major axis)..
 *
 *  \param f Ellipse parameter f (half the length of the major axis)
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param g Ellipse parameter g (half the length of the major axis minus the
 *           backing distance). See Catchpole, de Mestre, and Gill (1982).
 *  \param h Ellipse parameter h (half the length of the minor axis.
 *           See Catchpole, de Mestre, and Gill (1982).
 *  \param elapsedTime Elapsed time from fire ignition (assuming steady spread rate).
 *  \param thetaDegrees Angle (degrees) between the direction of maximum fire
 *           spread (the ellipse's major axis) and an arbitrary vector emanating
 *           from the \a ellipse \a center.  The arbitrary vector intersects the
 *           fire ellipse perimeter at some point 'p'.
 *
 *  \return The rate of expansion of the fire ellipse at point 'p' in the
 *  direction normal to the tangent of the ellipse perimeter at point 'p'.
 */
double FBL_SurfaceFireExpansionRateAtTheta( double f, double g, double h,
            double elapsedTime, double thetaDegrees )
{
    double psiDegrees = FBL_SurfaceFireEllipsePsiFromThetaDegrees( f, h, thetaDegrees );
    double rate       = FBL_SurfaceFireExpansionRateAtPsi( f, g, h,
                            psiDegrees, elapsedTime );
    return( rate );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the Psi version of the Beta fireline intensity
 *	by scaling it by the ratio of the psi-to-beta spread rates.
 *
 *  \param ros_psi Rate of spread at angle Psi (ft/min)
 *  \param ros_beta Rate of spread at angle Beta (ft/min)
 *	\param fli_beta Fireline intensity at angle Beta (Btu/ft/s)
 *
 *  \return Fireline (Byram's) intensity at angle Psi (Btu/ft/s).
 */
double FBL_SurfaceFireFirelineIntensityAtPsi( double ros_psi, double ros_beta,
	double fli_beta )
{
	return ( ros_beta < SMIDGEN || fli_beta < SMIDGEN )
		? ( 0.0 )
		: fli_beta * ros_psi / ros_beta;
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire spread rate at 'beta' degrees from the
 *  direction of maximum spread.
 *
 *  \param forwardSpreadRate Fire spread rate in the direction of maximum
 *                           spread (ft/min).
 *  \param eccentricity      Fire eccentricity (ft/ft).
 *  \param beta              Fire spread vector of interest (degrees clockwise
 *                           from direction of maximum spread).
 *
 *  \return Fire spread rate along the specified vector (ft/min).
 */
double FBL_SurfaceFireSpreadRateAtBeta( double forwardSpreadRate,
            double eccentricity, double beta )
{
    double rosVec = forwardSpreadRate;
    // Calculate the fire spread rate in this azimuth
    // if it deviates more than a tenth degree from the maximum azimuth
    if ( fabs( beta ) > 0.1 )
    {
        double radians = FBL_CompassDegreesToRadians( beta );
        rosVec = forwardSpreadRate * ( 1. - eccentricity )
               / ( 1. - eccentricity * cos( radians ) );
    }
    return( rosVec );
}
