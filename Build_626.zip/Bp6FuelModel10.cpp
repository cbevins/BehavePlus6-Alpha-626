#include "Bp6FuelModel10.h"
#include <math.h>

Bp6FuelModel10::Bp6FuelModel10() :
	Bp6SurfaceFire()
{
	init();
}

//------------------------------------------------------------------------------
Bp6FuelModel10::~Bp6FuelModel10()
{}

//------------------------------------------------------------------------------
/*!	\brief Initializes the base Bp6SurfaceFire instance with Fuel Model 10.
 */
void Bp6FuelModel10::init()
{
	// Crown fire model always uses standard fire behavior fuel model 10:
    static double depth     = 1.0;
    static double deadFuelMext = 0.25;
    static int    particles = 4;
    static int    life[4] = {     0,     0,     0,     2 };
    static double load[4] = { 0.138, 0.092, 0.230, 0.092 };
    static double savr[4] = { 2000.,  109.,   30., 1500. };
    static double heat[4] = { 8000., 8000., 8000., 8000. };
    static double dens[4] = {  32.0,  32.0,  32.0,  32.0 };
    static double stot[4] = { .0555, .0555, .0555, .0555 };
    static double seff[4] = { .0100, .0100, .0100, .0100 };
	setFuel( depth, deadFuelMext, particles, life, load, savr, heat, dens, stot, seff );
}