#ifndef BP6_FUEL_MODEL_10_H
#define BP6_FUEL_MODEL_10_H

#include "Bp6SurfaceFire.h"

class Bp6FuelModel10 : public Bp6SurfaceFire
{
public:
	Bp6FuelModel10();
	virtual ~Bp6FuelModel10();

private:
	void init();
};

#endif	// BP6_FUEL_MODEL_10_H
